import os


class Config(object):
    """Parent configuration class."""
    DEBUG = False
    CSRF_ENABLED = True
    SECRET = "VmC{$e3!O7-Fq-gL,SGc4u>]Q8|'MYF.ecSKQS.HK7g$Aw*goc${Eo5,Xi{b9Is"
    SOURCE_PATH = "datasets/dataset.csv"
    DATABASE = {
        "dialect": "mysql",
        "driver": "pymysql",
        "host": "insurancebitest.cpuguppngxjf.us-east-1.rds.amazonaws.com",
        "user": "InsuranceAdmin",
        "password": "insurancebi",
        "db": "InsuranceBI"
    }
    SQLALCHEMY_DATABASE_URI = '%s+%s://%s:%s@%s:3306/%s' % (
        DATABASE['dialect'],
        DATABASE['driver'],
        DATABASE['user'],
        DATABASE['password'],
        DATABASE['host'],
        DATABASE['db']
    )


class DevelopmentConfig(Config):
    """Configurations for Development."""
    DEBUG = True

class TestingConfig(Config):
    """Configurations for Development."""
    DEBUG = True
    TESTING = True


class ProductionConfig(Config):
    """Configurations for Production."""
    DEBUG = False
    TESTING = False


app_config = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'production': ProductionConfig,
}
