import os

from app import create_web_app

environment = "development"
app = create_web_app(environment)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)
