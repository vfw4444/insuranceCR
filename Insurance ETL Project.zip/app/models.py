from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()


class AgencyYears(db.Model):
    """This class represents the AgencyYears dimmension."""

    __tablename__ = 'AgencyYears'

    AgencyId         = db.Column(db.Integer, primary_key=True)
    State            = db.Column(db.String(255), primary_key=True)
    MasterAgency     = db.Column(db.Integer, primary_key=True)
    Year             = db.Column(db.Integer, primary_key=True)
    WrittenPremiums  = db.Column(db.Float)

    def __init__(self, AgencyId=None, State=None, MasterAgency=None, Year=None, WrittenPremiums=None):
        """initialize"""
        self.AgencyId        = AgencyId
        self.State           = State
        self.MasterAgency    = MasterAgency
        self.Year            = Year
        self.WrittenPremiums = WrittenPremiums

    @staticmethod
    def get_all():
        return AgencyYears.query.all()

    @staticmethod
    def get(AgencyId=None, MasterAgency=None, State=None, Year=None):
        result = AgencyYears.query
        if AgencyId is not None:
            result = result.filter(AgencyYears.AgencyId == AgencyId)
        if MasterAgency is not None:
            result = result.filter(AgencyYears.MasterAgency == MasterAgency)
        if State is not None:
            result = result.filter(AgencyYears.State == State)
        if Year is not None:
            result = result.filter(AgencyYears.Year == Year)

        return result.all()

    @staticmethod
    def getAgencies():
        result = AgencyYears.query.with_entities(AgencyYears.AgencyId).distinct().all()
        return result


class ProdLineYears(db.Model):
    """This class represents the ProdLineYears dimmension."""

    __tablename__ = 'ProdLineYears'

    ProductLineId    = db.Column(db.String(2), primary_key=True)
    Year             = db.Column(db.Integer, primary_key=True)
    WrittenPremiums  = db.Column(db.Float)

    def __init__(self, ProductLineId=None, Year=None, WrittenPremiums=None):
        """initialize"""
        self.ProductLineId   = idProdLine
        self.Year            = Year
        self.WrittenPremiums = WrittenPremiums

    @staticmethod
    def get_all():
        return ProdLineYears.query.all()

    @staticmethod
    def get(ProductLineId=None, Year=None):
        result = ProdLineYears.query
        if ProductLineId is not None:
            result = result.filter(ProdLineYears.ProductLineId == ProductLineId)
        if Year is not None:
            result = result.filter(ProdLineYears.Year == Year)

        return result.all()


class ProductYears(db.Model):
    """This class represents the ProductYears dimmension."""

    __tablename__ = 'ProductYears'

    ProductId        = db.Column(db.String(32), primary_key=True)
    Year             = db.Column(db.Integer, primary_key=True)
    WrittenPremiums  = db.Column(db.Float)

    def __init__(self, ProductId=None, Year=None, WrittenPremiums=None):
        """initialize"""
        self.ProductId       = ProductId
        self.Year            = Year
        self.WrittenPremiums = WrittenPremiums

    @staticmethod
    def get_all():
        return ProductYears.query.all()

    @staticmethod
    def get(ProductId=None, Year=None):
        result = ProductYears.query
        if ProductId is not None:
            result = result.filter(ProductYears.ProductId == ProductId)
        if Year is not None:
            result = result.filter(ProductYears.Year == Year)

        return result.all()


class StateYears(db.Model):
    """This class represents the StateYears dimmension."""

    __tablename__ = 'StateYears'

    State            = db.Column(db.String(32), primary_key=True)
    Year             = db.Column(db.Integer, primary_key=True)
    WrittenPremiums  = db.Column(db.Float)

    def __init__(self, State=None, Year=None, WrittenPremiums=None):
        """initialize"""
        self.State           = State
        self.Year            = Year
        self.WrittenPremiums = WrittenPremiums

    @staticmethod
    def get_all():
        return StateYears.query.all()

    @staticmethod
    def get(State=None, Year=None):
        result = StateYears.query
        if State is not None:
            result = result.filter(StateYears.State == State)
        if Year is not None:
            result = result.filter(StateYears.Year == Year)

        return result.all()


class VendorYears(db.Model):
    """This class represents the VendorYears dimmension."""

    __tablename__ = 'VendorYears'

    VendorId         = db.Column(db.String(1), primary_key=True)
    Year             = db.Column(db.Integer, primary_key=True)
    WrittenPremiums  = db.Column(db.Float)

    def __init__(self, VendorId=None, Year=None, WrittenPremiums=None):
        """initialize"""
        self.VendorId        = VendorId
        self.Year            = Year
        self.WrittenPremiums = WrittenPremiums

    @staticmethod
    def get_all():
        return VendorYears.query.all()

    @staticmethod
    def get(VendorId=None, Year=None):
        result = VendorYears.query
        if VendorId is not None:
            result = result.filter(VendorYears.VendorId == VendorId)
        if Year is not None:
            result = result.filter(VendorYears.Year == Year)

        return result.all()
