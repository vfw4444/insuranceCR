import colorsys

def get_spaced_colors(N):
    HSV_tuples = [(x*1.0/N, 0.5, 0.5) for x in range(N)]
    RGB_tuples = map(lambda x: colorsys.hsv_to_rgb(*x), HSV_tuples)

    rgb_col = ['rgb('+str(int(float(i[0]) * 255))+','+str(int(float(i[1]) * 255))+','+str(int(float(i[2]) * 255))+')' for i in list(RGB_tuples)]
    return rgb_col
