from flask import Flask, render_template, Markup, make_response
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.sql import func
from flask import request, jsonify, abort
from config import app_config
from flask_cors import CORS, cross_origin
from plotly.offline import plot, iplot
import plotly.plotly as py
import plotly.graph_objs as go

from app.models import AgencyYears
from app.models import ProdLineYears
from app.models import ProductYears
from app.models import StateYears
from app.models import VendorYears
from app.util import *

def export_csv(name, data):
    import csv
    from io import StringIO

    if len(data) > 0:
        si = StringIO()
        cw = csv.DictWriter(si, data[0].keys())
        cw.writeheader()
        cw.writerows(data)
        output = make_response(si.getvalue())
        output.headers["Content-Disposition"] = "attachment; filename="+str(name)+".csv"
        output.headers["Content-type"] = "text/csv"
        return output
    else:
        return None

def export_xls(name, data):
    import xlwt
    from io import StringIO, BytesIO

    si = BytesIO()
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet(name)

    row_num = 0
    if len(data) > 0:
        columns = list(data[0].keys())

        font_style = xlwt.XFStyle()
        font_style.font.bold = True

        for col_num in range(len(columns)):
            ws.write(row_num, col_num, columns[col_num], font_style)

        font_style = xlwt.XFStyle()
        font_style.alignment.wrap = 1

        for item in data:
            row = [item[x] for x in item]
            row_num += 1
            for col_num in range(len(row)):
                ws.write(row_num, col_num, row[col_num], font_style)
        wb.save(si)

        output = make_response(si.getvalue())
        output.headers["Content-Disposition"] = "attachment; filename="+str(name)+".xls"
        output.headers["Content-type"] = "application/ms-excel"
        return output
    else:
        return None


def create_web_app(environment):
    db = SQLAlchemy()
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(app_config[environment])
    app.config.from_pyfile('../config.py')
    app.config['TEMPLATES_AUTO_RELOAD'] = True
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['CORS_HEADERS'] = 'Content-Type'
    app.config['SQLALCHEMY_POOL_RECYCLE'] = 299
    app.config['SQLALCHEMY_POOL_TIMEOUT'] = 20
    db.init_app(app)

    ###############################################
    ##
    ## AgencyYears dimmension
    ##
    ###############################################
    @app.route('/api/AgencyYears', methods=['GET'])
    @cross_origin()
    def getAgencyYearsDimension():
        AgencyId        = request.args.get('AgencyId', None)
        State           = request.args.get('State', None)
        MasterAgency    = request.args.get('MasterAgency', None)
        Year            = request.args.get('Year', None)
        ResponseType    = request.args.get('response_type', None)

        agencyYearsList = AgencyYears.get(AgencyId, MasterAgency, State, Year)
        results = []

        for agencyYears in agencyYearsList:
            obj = {
                'AgencyId':         agencyYears.AgencyId,
                'State':            agencyYears.State,
                'MasterAgency':     agencyYears.MasterAgency,
                'Year':             agencyYears.Year,
                'WrittenPremiums':  agencyYears.WrittenPremiums,
            }
            results.append(obj)
        if ResponseType is None:
            return jsonify(results), 200
        elif ResponseType == 'csv':
            return export_csv('AgencyYears', results)
        elif ResponseType == 'xls':
            return export_xls('AgencyYears', results)


    @app.route('/api/AgencyYears/Metadata', methods=['GET'])
    @cross_origin()
    def getAgencyYearsMetadata():
        agenciesList        = AgencyYears.query.with_entities(AgencyYears.AgencyId).distinct().all()
        statesList          = AgencyYears.query.with_entities(AgencyYears.State).distinct().all()
        masterAgenciesList  = AgencyYears.query.with_entities(AgencyYears.MasterAgency).distinct().all()
        yearsList           = AgencyYears.query.with_entities(AgencyYears.Year).distinct().all()

        result = {
            'Agencies': [item.AgencyId for item in agenciesList],
            'States': [item.State for item in statesList],
            'MasterAgencies': [item.MasterAgency for item in masterAgenciesList],
            'Years': [item.Year for item in yearsList]
        }

        return jsonify(result), 200

    #@app.route('/api/AgencyYears/download/<type>', methods=['GET'])
    #@cross_origin()
    #def downloadAgencyYears(type):



    ###############################################
    ##
    ## ProdLineYears dimmension
    ##
    ###############################################
    @app.route('/api/ProdLineYears', methods=['GET'])
    @cross_origin()
    def getProdLineYearsDimension():
        ProductLineId   = request.args.get('ProductLineId', None)
        Year            = request.args.get('Year', None)
        ResponseType    = request.args.get('response_type', None)

        prodLineYears = ProdLineYears.get(ProductLineId, Year)
        results = []

        for prodLineYear in prodLineYears:
            obj = {
                'ProductLineId':        prodLineYear.ProductLineId,
                'Year':                 prodLineYear.Year,
                'WrittenPremiums':      prodLineYear.WrittenPremiums,
            }
            results.append(obj)

        if ResponseType is None:
            return jsonify(results), 200
        elif ResponseType == 'csv':
            return export_csv('ProdLineYears', results)
        elif ResponseType == 'xls':
            return export_xls('ProdLineYears', results)

    @app.route('/api/ProdLineYears/Metadata', methods=['GET'])
    @cross_origin()
    def getProdLineYearsMetadata():
        prodlinesList   = ProdLineYears.query.with_entities(ProdLineYears.ProductLineId).distinct().all()
        yearsList       = ProdLineYears.query.with_entities(ProdLineYears.Year).distinct().all()

        result = {
            'ProductLines': [item.ProductLineId for item in prodlinesList],
            'Years': [item.Year for item in yearsList]
        }

        return jsonify(result), 200


    ###############################################
    ##
    ## ProductYears dimmension
    ##
    ###############################################
    @app.route('/api/ProductYears', methods=['GET'])
    def getProductYearsDimension():
        ProductId   = request.args.get('ProductId', None)
        Year        = request.args.get('Year', None)
        ResponseType    = request.args.get('response_type', None)

        productYears = ProductYears.get(ProductId, Year)
        results = []

        for productYear in productYears:
            obj = {
                'ProductId':        productYear.ProductId,
                'Year':             productYear.Year,
                'WrittenPremiums':  productYear.WrittenPremiums,
            }
            results.append(obj)

        if ResponseType is None:
            return jsonify(results), 200
        elif ResponseType == 'csv':
            return export_csv('ProductYears', results)
        elif ResponseType == 'xls':
            return export_xls('ProductYears', results)

    @app.route('/api/ProductYears/Metadata', methods=['GET'])
    @cross_origin()
    def getProductYearsMetadata():
        productsList    = ProductYears.query.with_entities(ProductYears.ProductId).distinct().all()
        yearsList       = ProductYears.query.with_entities(ProductYears.Year).distinct().all()

        result = {
            'Products': [item.ProductId for item in productsList],
            'Years': [item.Year for item in yearsList]
        }

        return jsonify(result), 200


    ###############################################
    ##
    ## StateYears dimmension
    ##
    ###############################################
    @app.route('/api/StateYears', methods=['GET'])
    def getStateYearsDimension():
        State       = request.args.get('State', None)
        Year        = request.args.get('Year', None)
        ResponseType    = request.args.get('response_type', None)

        stateYears = StateYears.get(State, Year)
        results = []

        for stateYear in stateYears:
            obj = {
                'State':            stateYear.State,
                'Year':             stateYear.Year,
                'WrittenPremiums':  stateYear.WrittenPremiums,
            }
            results.append(obj)

        if ResponseType is None:
            return jsonify(results), 200
        elif ResponseType == 'csv':
            return export_csv('StateYears', results)
        elif ResponseType == 'xls':
            return export_xls('StateYears', results)

    @app.route('/api/StateYears/Metadata', methods=['GET'])
    @cross_origin()
    def getStateYearsMetadata():
        statesList  = StateYears.query.with_entities(StateYears.State).distinct().all()
        yearsList   = StateYears.query.with_entities(StateYears.Year).distinct().all()

        result = {
            'States': [item.State for item in statesList],
            'Years': [item.Year for item in yearsList]
        }

        return jsonify(result), 200


    ###############################################
    ##
    ## VendorYears dimmension
    ##
    ###############################################
    @app.route('/api/VendorYears', methods=['GET'])
    def getVendorYearsDimension():
        VendorId    = request.args.get('VendorId', None)
        Year        = request.args.get('Year', None)
        ResponseType    = request.args.get('response_type', None)

        vendorYears = VendorYears.get(VendorId, Year)
        results = []

        for vendorYear in vendorYears:
            obj = {
                'VendorId':         vendorYear.VendorId,
                'Year':             vendorYear.Year,
                'WrittenPremiums':  vendorYear.WrittenPremiums,
            }
            results.append(obj)

        if ResponseType is None:
            return jsonify(results), 200
        elif ResponseType == 'csv':
            return export_csv('VendorYears', results)
        elif ResponseType == 'xls':
            return export_xls('VendorYears', results)

    @app.route('/api/VendorYears/Metadata', methods=['GET'])
    @cross_origin()
    def getVendorYearsMetadata():
        vendorsList     = VendorYears.query.with_entities(VendorYears.VendorId).distinct().all()
        yearsList       = VendorYears.query.with_entities(VendorYears.Year).distinct().all()

        result = {
            'Vendors': [item.VendorId for item in vendorsList],
            'Years': [item.Year for item in yearsList]
        }

        return jsonify(result), 200

    ###############################################
    ##
    ## Dashboard
    ##
    ###############################################
    @app.route('/', methods=['GET'])
    def homepage():
        return render_template("dashboard.html")

    @app.route('/toolbars/<toolbar>', methods=['GET'])
    def toolbars(toolbar):
        return render_template("toolbars/"+toolbar+'.html')

    @app.route('/plot/<view>')
    def showPlot(view):

        x = []
        y = []
        spaces = 0
        year        = request.args.get('Year', None)

        if view == "ProdLineYears":
            prodLineYears = ProdLineYears.query.with_entities(
                ProdLineYears.ProductLineId,
                func.sum(ProdLineYears.WrittenPremiums).label('WrittenPremiums')
            )
            if year is not None:
                prodLineYears = prodLineYears.filter(ProductYears.Year == year)

            prodLineYears = prodLineYears.group_by(ProdLineYears.ProductLineId).all()

            x = [item.ProductLineId for item in prodLineYears]
            y = [
                item.WrittenPremiums
                for item in prodLineYears
            ]

        if view == "AgencyYears":
            x = [str(item.MasterAgency)+'-' for item in AgencyYears.query.with_entities(AgencyYears.MasterAgency).distinct().all()]
            if year is None:
                y = [
                    item.WrittenPremiums
                    for item in AgencyYears.query.with_entities(func.sum(AgencyYears.WrittenPremiums).label('WrittenPremiums')).group_by(AgencyYears.MasterAgency).all()
                ]
            else:
                y = [
                    item.WrittenPremiums
                    for item in AgencyYears.query.with_entities(func.sum(AgencyYears.WrittenPremiums).label('WrittenPremiums')).group_by(AgencyYears.MasterAgency).filter(AgencyYears.Year == year).all()
                ]
        if view == "ProductYears":
            x = [str(item.ProductId) for item in ProductYears.query.with_entities(ProductYears.ProductId).distinct().all()]
            if year is None:
                y = [
                    item.WrittenPremiums
                    for item in ProductYears.query.with_entities(func.sum(ProductYears.WrittenPremiums).label('WrittenPremiums')).group_by(ProductYears.ProductId).all()
                ]
            else:
                y = [item.WrittenPremiums for item in ProductYears.get(None, year)]

        if view == "StateYears":
            x = [str(item.State) for item in StateYears.query.with_entities(StateYears.State).distinct().all()]
            if year is None:
                y = [
                    item.WrittenPremiums
                    for item in StateYears.query.with_entities(func.sum(StateYears.WrittenPremiums).label('WrittenPremiums')).group_by(StateYears.State).all()
                ]
            else:
                y = [item.WrittenPremiums for item in StateYears.get(None, year)]

        if view == "VendorYears":
            x = [str(item.VendorId) for item in VendorYears.query.with_entities(VendorYears.VendorId).distinct().all()]
            if year is None:
                y = [
                    item.WrittenPremiums
                    for item in VendorYears.query.with_entities(func.sum(VendorYears.WrittenPremiums).label('WrittenPremiums')).group_by(VendorYears.VendorId).all()
                ]
            else:
                y = [item.WrittenPremiums for item in VendorYears.get(None, year)]

        plot_content = None
        if view == "ProdLineYears":
            spaces = len(x)
            data = [go.Pie(labels=x, values=y, insidetextfont = dict(color = '#FFFFFF', size=18))]
            layout = go.Layout(width='100%', height='100%', autosize=False)
            fig = go.Figure(data=data, layout=layout)
            plot_content = plot(fig, output_type='div')
        else:
            spaces = len(x)
            trace1 = go.Bar(
                x=x,
                y=y,
                name=view,
                marker=dict(
                    color=get_spaced_colors(spaces)
                )
            )

            data = [trace1]
            layout = go.Layout(barmode='stack', width='100%', height='100%', autosize=False)
            fig = go.Figure(data=data, layout=layout)

            plot_content = plot(fig, output_type='div')

        return render_template("plot.html", plot_chart=Markup(plot_content))

    return app
