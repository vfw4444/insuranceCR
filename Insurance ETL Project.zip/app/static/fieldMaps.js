var fieldMaps = {
  "AgencyYears": {
    "AgencyId": "Agency Id",
    "MasterAgency": "Master Agency",
    "State": "State",
    "WrittenPremiums": "Written Premiums"
  },
  "ProdLineYears": {
    "ProductLineId": "Product Line",
    "WrittenPremiums": "Written Premiums"
  },
  "ProductYears": {
    "ProductId": "Product Id",
    "WrittenPremiums": "Written Premiums"
  },
  "StateYears": {
    "State": "State",
    "WrittenPremiums": "Written Premiums"
  },
  "VendorYears": {
    "VendorId": "Vendor Id",
    "WrittenPremiums": "Written Premiums"
  }
}
