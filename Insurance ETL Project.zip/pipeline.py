import pandas as pd
from pandas.io import sql
import MySQLdb
import pymysql
from sqlalchemy import create_engine
import argparse
import logging
import os
import sys
from config import app_config


"""
    Initialize step
"""
handler = logging.StreamHandler()
root = logging.getLogger()
root.setLevel(os.environ.get("LOGLEVEL", "INFO"))
root.addHandler(handler)

logging.info("Initializing\n")

logging.info("Initialization - Success\n")

def createMySQLConnection(configurations):
    try:
        logging.info("Connecting to MySQL...")
        engine = create_engine(
            'mysql+pymysql://%s:%s@%s:3306/%s' % (
                configurations['user'],
                configurations['password'],
                configurations['host'],
                configurations['db']
            ),
            echo=False
        )
        logging.info("Connected to MySQL - Success\n")
        return engine
    except Exception as e:
        logging.error("Connected to MySQL - Failed\n"+str(e))
        sys.exit(-1)

def readCSV(source_file):
    # Read CSV into dataframe
    try:
        logging.info("Reading CSV...")
        source_df = pd.read_csv(source_file, index_col=False, engine='python')
        logging.info("CSV read - Success\n")
        return source_df
    except Exception as e:
        logging.error("CSV read - Failed\n"+str(e))
        sys.exit(-1)

def generateSummarizedView(df, groupby, sumColumn, targetColumns=None):
    allColumns = groupby.copy()
    allColumns.append(sumColumn)
    summarized_df = df.groupby(groupby, as_index=False)[allColumns].transform(sum).drop_duplicates()
    if targetColumns is not None:
        summarized_df.columns = targetColumns
    return summarized_df

if __name__ == "__main__":

    #parser = argparse.ArgumentParser()
    #parser.add_argument('-f', action='store', help='Specify source file path')

    #args = parser.parse_args()
    #from_file = args.f
    from_file = app_config['production'].SOURCE_PATH

    # Load Dataframe into the MySQL table
    try:
        logging.info("Loading data to MySQL...")

        # creating AgencyYears Dataframe and storing to MySQL
        mysql_connection = createMySQLConnection(app_config['production'].DATABASE)
        source_df = readCSV(from_file)

        agency_years_df = generateSummarizedView(
            source_df,
            ['AGENCY_ID', 'STATE_ABBR', 'PRIMARY_AGENCY_ID', 'STAT_PROFILE_DATE_YEAR'],
            'WRTN_PREM_AMT',
            ['AgencyId', 'State', 'MasterAgency', 'Year', 'WrittenPremiums']
        )
        agency_years_df.to_sql(con=mysql_connection, name='AgencyYears', if_exists='append', index=False)
        logging.info("AgencyYears loaded")

        # creating ProdLineYears Dataframe and storing to MySQL
        prod_line_df = generateSummarizedView(
            source_df,
            ['PROD_LINE', 'STAT_PROFILE_DATE_YEAR'],
            'WRTN_PREM_AMT',
            ['ProductLineId', 'Year', 'WrittenPremiums']
        )
        prod_line_df.to_sql(con=mysql_connection, name='ProdLineYears', if_exists='append', index=False)
        logging.info("ProdLineYears loaded")


        # creating ProductYears Datafrane and storing to MySQL
        prod_years_df = generateSummarizedView(
            source_df,
            ['PROD_ABBR', 'STAT_PROFILE_DATE_YEAR'],
            'WRTN_PREM_AMT',
            ['ProductId', 'Year', 'WrittenPremiums']
        )
        prod_years_df.to_sql(con=mysql_connection, name='ProductYears', if_exists='append', index=False)
        logging.info("ProductYears loaded")


        # creating StateYears Datafrane and storing to MySQL
        state_years_df = generateSummarizedView(
            source_df,
            ['STATE_ABBR', 'STAT_PROFILE_DATE_YEAR'],
            'WRTN_PREM_AMT',
            ['State', 'Year', 'WrittenPremiums']
        )
        state_years_df.to_sql(con=mysql_connection, name='StateYears', if_exists='append', index=False)
        logging.info("StateYears loaded")

        # creating VendorYears Datafrane and storing to MySQL
        vendor_years_df = generateSummarizedView(
            source_df,
            ['VENDOR_IND', 'STAT_PROFILE_DATE_YEAR'],
            'WRTN_PREM_AMT',
            ['VendorId', 'Year', 'WrittenPremiums']
        )
        vendor_years_df.to_sql(con=mysql_connection, name='VendorYears', if_exists='append', index=False)
        logging.info("VendorYears loaded")

        # load raw data form csv

        source_df.to_sql(con=mysql_connection, name='InsuredDetails', if_exists='append', index=False)
        logging.info("InsuredDetails loaded")


        logging.info("Load data to MySQL - Success\n")
    except Exception as e:
        logging.error("Load data to MySQL - Failed\n"+str(e))
        sys.exit(-1)
