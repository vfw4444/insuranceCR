import unittest
import os
from app import create_web_app
from flask_sqlalchemy import SQLAlchemy
import json


db = SQLAlchemy()

class SummaryViewTestCase:
    """This class servers as a base class for all below test cases"""
    view = None

    def setUp(self):
        """Define test variables and initialize app."""
        self.app = create_web_app("testing")
        self.client = self.app.test_client

        # binds the app to the current context
        with self.app.app_context():
            # create all tables
            db.create_all()

    def test_api_get_all(self):
        """Test API can get all dimension records"""
        res = self.client().get('/api/'+str(self.view))
        self.assertEqual(res.status_code, 200)
        data = json.loads(str(res.data))
        self.assertTrue(len(data) > 0)

    def test_api_get_filtered(self):
        """Test API can get filtered dimension records"""
        res = self.client().get('/api/'+str(self.view)+'?Year=2015')
        self.assertEqual(res.status_code, 200)
        data = json.loads(str(res.data))
        self.assertTrue(len(data) > 0)

    def test_api_get_unexisting(self):
        """Test API return empty list on geting unexisting dimension records"""
        res = self.client().get('/api/'+str(self.view)+'?Year=2017')
        self.assertEqual(res.status_code, 200)
        data = json.loads(str(res.data))
        self.assertFalse(len(data) > 0)

    def test_api_get_metadata(self):
        """Test API can get metadata"""
        res = self.client().get('/api/'+str(self.view)+'/Metadata')
        self.assertEqual(res.status_code, 200)
        data = json.loads(str(res.data))
        self.assertTrue(len(data) > 0)

##############################################################################
##
## Below classes are specific unittest Test Cases. They folows the
## base class (SummaryViewTestCase) flow
##
##############################################################################


class AgencyYearsTestCase(SummaryViewTestCase, unittest.TestCase):
    """This class represents the AgencyYears test case"""
    def setUp(self):
        """Define test variables and initialize app."""
        self.app = create_web_app("testing")
        self.client = self.app.test_client
        self.view = 'AgencyYears'
        self.app.app_context()

class ProdLineYearsTestCase(SummaryViewTestCase, unittest.TestCase):
    """This class represents the ProdLineYears test case"""
    def setUp(self):
        """Define test variables and initialize app."""
        self.app = create_web_app("testing")
        self.client = self.app.test_client
        self.view = 'ProdLineYears'
        self.app.app_context()

class ProductYearsTestCase(SummaryViewTestCase, unittest.TestCase):
    """This class represents the ProductYears test case"""
    def setUp(self):
        """Define test variables and initialize app."""
        self.app = create_web_app("testing")
        self.client = self.app.test_client
        self.view = 'ProductYears'
        self.app.app_context()

class StateYearsTestCase(SummaryViewTestCase, unittest.TestCase):
    """This class represents the StateYears test case"""
    def setUp(self):
        """Define test variables and initialize app."""
        self.app = create_web_app("testing")
        self.client = self.app.test_client
        self.view = 'StateYears'
        self.app.app_context()

class VendorYearsTestCase(SummaryViewTestCase, unittest.TestCase):
    """This class represents the VendorYears test case"""
    def setUp(self):
        """Define test variables and initialize app."""
        self.app = create_web_app("testing")
        self.client = self.app.test_client
        self.view = 'VendorYears'
        self.app.app_context()


# Make the tests conveniently executable
if __name__ == "__main__":
    unittest.main()
